package compiler.CodeGen;
import compiler.Parser.*;
public interface ASTGen {
    void genera(ASTNode node);
}
