package compiler.CodeGen;

import compiler.Lexer.*;
import compiler.Parser.ASTNode;
import compiler.Parser.*;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.lang.reflect.RecordComponent;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;


public class CodeGen {

    private final Program program;
    private  ClassWriter cw;
    private  MethodVisitor mv;
    private final String outputClassPath;
    private Lexer lexer;
    private Symbol currentSymbol;
    private Symbol nextSymbol;

    public CodeGen(Program program, String outputClassPath) throws IOException {
        this.program = program;
        this.outputClassPath = outputClassPath;
    }

    public void generate() throws IOException {
        // 1. create output path if does not exist
        Path outputPath = Paths.get(outputClassPath);
        Path outputDir = outputPath.getParent();
        if (outputDir != null && !Files.exists(outputDir)) {
            Files.createDirectories(outputDir);
        }
        // 2. Start generating the main class
        cw = new ClassWriter(0);
        cw.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, "Main", null, "java/lang/Object", null);

        // 3. create class file for record
        for (ASTNode smth : program.getStatements()) {
            if (smth instanceof RecordDefinition) {
                emitRecord((RecordDefinition) smth, outputDir.toString());
            }
            if (smth instanceof FunctionDeclaration) {
                emitFunction((FunctionDeclaration) smth, outputDir.toString());
            }
            if(smth instanceof ConstantDeclaration) {
                cw.visitField(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_FINAL,
                        ((ConstantDeclaration) smth).getName(), desc(((ConstantDeclaration) smth).getType().toString()), null, null).visitEnd();
            }
        }


        // 4. Generate the default constructor
        emitDefaultConstructor();
        emitClinit();

        // 6. Generate the main method
        FunctionDeclaration mainFn = program.getMainFn();
        if (mainFn == null) {
            System.out.println("No main function found");
            return;
        }
        emitMain(mainFn, "Main");

        // 7. Write the class to the output file
        cw.visitEnd();
        byte[] classBytes = cw.toByteArray();
        Files.write(outputPath, classBytes);

    }

    public String desc(String typeNode) {
        switch(typeNode){
            case "int":
                return "I";
            case "bool":
                return "Z";
            case "string":
                return "Ljava/lang/String;";
            case "void":
                return "V";
            default:
                throw new IllegalArgumentException("Unknown type: " + typeNode);
        }
    }

    private void emitRecord(RecordDefinition record, String outputDir) throws IOException {
        String recordName = record.getRecordName();
        ClassWriter cw = new ClassWriter(0);
        cw.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, recordName, null, "java/lang/Object", null);

        // Generate fields
        for (ASTNode field : record.getFields()) {
            if (field instanceof FieldDeclaration) {
                FieldDeclaration fieldDecl = (FieldDeclaration) field;
                String fieldName = fieldDecl.getFieldName();
                String fieldType = fieldDecl.getType().toString();
                cw.visitField(Opcodes.ACC_PUBLIC, fieldName, desc(fieldType), null, null).visitEnd();
            }
        }

        StringBuilder ctorsig = new StringBuilder("(");
        for(ASTNode field : record.getFields()) {
            if (field instanceof FieldDeclaration) {
                FieldDeclaration fieldDecl = (FieldDeclaration) field;
                String fieldType = fieldDecl.getType().toString();
                ctorsig.append(desc(fieldType));
            }
        }
        ctorsig.append(")");

        // Generate default constructor
        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", ctorsig.toString(), null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0); //push this

        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false); // Call super constructor

        // Set fields
        int index = 1; // Start from 1 to skip 'this'

        for(ASTNode field : record.getFields()) {
            if (field instanceof FieldDeclaration) {
                FieldDeclaration fieldDecl = (FieldDeclaration) field;
                String fieldName = fieldDecl.getFieldName();
                String fieldType = fieldDecl.getType().toString();

                // Load the argument onto the stack
                mv.visitVarInsn(Opcodes.ALOAD, 0);
                mv.visitVarInsn(Objects.equals(fieldType, "int") ? org.objectweb.asm.Opcodes.ILOAD : org.objectweb.asm.Opcodes.LLOAD, index); // Load the argument
                mv.visitFieldInsn(Opcodes.PUTFIELD, recordName, fieldName, desc(fieldType));
                index += Objects.equals(fieldType, "int") ? 1 : 2;
            }
        }
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(-1, -1);

        mv.visitEnd();
        cw.visitEnd();

        // Write the class to the output directory
        Path outputPath = Paths.get(outputDir, recordName + ".class");
        byte[] classBytes = cw.toByteArray();
        Files.write(outputPath, classBytes);
    }

    private void emitMain(FunctionDeclaration mainFn, String className) {
        mv = cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "main", "([Ljava/lang/String;)V", null, null);
        mv.visitCode();
        // no named parameters—but if you want to reference args, slot 0 holds the String[]
        HashMap<Object, Object> localSlots = new HashMap<>();
        // localSlots.put("args", 0);

        // emit main body
        mainFn.getBody().accept(new ASTGen(mv, localSlots));

        mv.visitInsn(RETURN);
        mv.visitMaxs(-1, -1);
        mv.visitEnd();
    }

    private void emitDefaultConstructor() {
        mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(1, 1); // or 1,1
        mv.visitEnd();
    }

    private void emitClinit() {// for constant declarations
        mv = cw.visitMethod(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
        mv.visitCode();
        for(ASTNode smth : program.getStatements()) {
            if (smth instanceof ConstantDeclaration cd) {
                emitExpression(cd.getExpression());
                mv.visitFieldInsn(Opcodes.PUTSTATIC, "Main", cd.getName(), desc(cd.getType().toString()));
            }
        }
        mv.visitInsn(RETURN);
        mv.visitMaxs(-1, -1);
        mv.visitEnd();
    }

    private void emitFunction(FunctionDeclaration function, String outputDir) throws IOException {
        StringBuilder sig = new StringBuilder("(");
        for (Parameter param : function.getParameters()) {
            sig.append(desc(param.getType().toString()));
        }
        sig.append(")");
        sig.append(function.getReturnType() == null ? "V" : desc(function.getReturnType().toString()));
        mv = cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, function.getFunctionName(), sig.toString(), null, null);
        mv.visitCode();

        // Generate local variable slots
        HashMap<Object, Object> localSlots = new HashMap<>();
        int index = 0;
        for (Parameter param : function.getParameters()) {
            localSlots.put(param.getParameterName(), index);
            index += Objects.equals(param.getType().toString(), "int") ? 1 : 2; // Assuming int is 4 bytes and other types are 8 bytes
        }

        function.getBody().accept(new CodeGenVisitor(mv, localSlots)); // Assuming CodeGenVisitor is a class that handles the AST nodes

        if(function.getReturnType() != null) {
            if(function.getReturnType().isIntOrBool()) {
                mv.visitInsn(Opcodes.ICONST_0);
                mv.visitInsn(Opcodes.IRETURN);
            } else {
                mv.visitInsn(Opcodes.ACONST_NULL);
                mv.visitInsn(Opcodes.ARETURN);
            }
        } else {
            mv.visitInsn(Opcodes.RETURN);
        }
        mv.visitMaxs(-1, -1);
        mv.visitEnd();
    }



    private void emitExpression(Object value) {

    }



}